var swiper = new Swiper(".users-slide", {

 slidesPerView: "auto",
      spaceBetween: 30,
    breakpoints: {
        // when window width is >= 320px
        501: {
          slidesPerView: 2,
          spaceBetween: 20
        },
        // when window width is >= 480px
        767: {
          slidesPerView: 3,
          spaceBetween: 10
        },
        // when window width is >= 640px
        991: {
          slidesPerView: 4,
          spaceBetween: 20
        }
      }
  });

$('#gallery').slick({
  slidesToShow: 6,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 0,
  speed: 2000,
  pauseOnHover: false,
  cssEase: 'linear',
   responsive: [
      {
        breakpoint: 991,
        settings: {
          slidesToShow: 3,
        }
      },
      {
        breakpoint: 767,
        settings: {
          slidesToShow: 3,
        }
      },


       {
        breakpoint: 500,
        settings: {
          slidesToShow: 2,
        }
      }
    ]
});


         $("#home_visit").click(function() {
           $("#locationform").removeClass("d-none");
           $("#location").removeClass("d-none");
        });

        $("#lab_visit").click(function() {
           $("#locationform").addClass("d-none");
           $("#location").addClass("d-none");
        });





$(document).ready(function () {
  
  $(".btn_ele-cp").click(function (){
    $(this).addClass("active").siblings().removeClass("active");
  });
});